import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { MedicineCard } from "@/components/medicine/medicine-card"
import { CategoryCard } from "@/components/medicine/category-card"
import { db } from "@/lib/db"

export default async function HomePage() {
  // Fetch featured medicines
  const featuredMedicines = await db.medicine.findMany({
    take: 8,
    orderBy: {
      createdAt: "desc",
    },
  })

  const categories = [
    {
      id: "medicines",
      name: "Medicines",
      icon: "pill",
      description: "Prescription and over-the-counter medicines",
    },
    {
      id: "healthcare",
      name: "Healthcare",
      icon: "stethoscope",
      description: "Healthcare devices and equipment",
    },
    {
      id: "wellness",
      name: "Wellness",
      icon: "heart",
      description: "Products for your wellness and lifestyle",
    },
    {
      id: "fitness",
      name: "Fitness",
      icon: "activity",
      description: "Supplements and fitness equipment",
    },
    {
      id: "baby-care",
      name: "Baby Care",
      icon: "baby",
      description: "Products for baby care and nutrition",
    },
    {
      id: "ayurveda",
      name: "Ayurveda",
      icon: "leaf",
      description: "Traditional Ayurvedic medicines and products",
    },
  ]

  return (
    <>
      <Header />
      <main>
        <section className="hero relative h-[500px] flex items-center">
          <div className="container">
            <div className="max-w-xl space-y-5">
              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">Your Health, Our Priority</h1>
              <p className="text-xl text-white/90">
                Find the medicines you need with our advanced search and recognition system. Scan your medicine to find
                alternatives and the best prices.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <Link href="/medicines">Browse Medicines</Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-white/10 text-white hover:bg-white/20">
                  <Link href="/scan">Scan Medicine</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tight mb-8">Shop by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {categories.map((category) => (
                <CategoryCard
                  key={category.id}
                  id={category.id}
                  name={category.name}
                  icon={category.icon}
                  description={category.description}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold tracking-tight">Featured Medicines</h2>
              <Button variant="outline" asChild>
                <Link href="/medicines">View All</Link>
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredMedicines.map((medicine) => (
                <MedicineCard
                  key={medicine.id}
                  id={medicine.id}
                  name={medicine.name}
                  description={medicine.description}
                  price={medicine.price}
                  discountPrice={medicine.discountPrice}
                  image={medicine.image}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-primary/5">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tight">Scan Your Medicine, Find Alternatives</h2>
                <p className="text-lg text-muted-foreground">
                  Our advanced medicine recognition system allows you to scan your medicine packaging and find
                  alternatives with the same composition. Save time and money by finding the best options available.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                      <div className="h-2 w-2 rounded-full bg-primary" />
                    </div>
                    <span>Scan medicine packaging with your camera</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                      <div className="h-2 w-2 rounded-full bg-primary" />
                    </div>
                    <span>Upload images of your prescriptions</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                      <div className="h-2 w-2 rounded-full bg-primary" />
                    </div>
                    <span>Find medicines with the same composition</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                      <div className="h-2 w-2 rounded-full bg-primary" />
                    </div>
                    <span>Compare prices and save money</span>
                  </li>
                </ul>
                <Button size="lg" asChild>
                  <Link href="/scan">Try Scanning Now</Link>
                </Button>
              </div>
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image src="/images/medicine-scan.jpg" alt="Medicine scanning feature" fill className="object-cover" />
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

