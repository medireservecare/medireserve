import Image from "next/image"
import { notFound } from "next/navigation"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { AddToCartButton } from "@/components/medicine/add-to-cart-button"
import { db } from "@/lib/db"

interface MedicineDetailPageProps {
  params: {
    id: string
  }
}

export default async function MedicineDetailPage({ params }: MedicineDetailPageProps) {
  const medicine = await db.medicine.findUnique({
    where: { id: params.id },
  })

  if (!medicine) {
    notFound()
  }

  const discount = medicine.discountPrice
    ? Math.round(((medicine.price - medicine.discountPrice) / medicine.price) * 100)
    : 0

  return (
    <>
      <Header />
      <main className="container py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
            <Image
              src={medicine.image || "/images/medicine-placeholder.jpg"}
              alt={medicine.name}
              fill
              className="object-cover"
            />
            {discount > 0 && (
              <div className="absolute top-4 right-4 bg-green-600 text-white text-sm font-medium px-2 py-1 rounded">
                {discount}% off
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{medicine.name}</h1>
              <p className="text-muted-foreground mt-2">{medicine.description}</p>
            </div>

            <div className="flex items-center gap-2">
              {medicine.discountPrice ? (
                <>
                  <span className="text-3xl font-bold">₹{medicine.discountPrice.toFixed(2)}</span>
                  <span className="text-lg text-muted-foreground line-through">₹{medicine.price.toFixed(2)}</span>
                </>
              ) : (
                <span className="text-3xl font-bold">₹{medicine.price.toFixed(2)}</span>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="font-medium">Manufacturer:</span>
                <span>{medicine.manufacturer}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">Category:</span>
                <span>{medicine.category}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">Stock:</span>
                <span>{medicine.stock > 0 ? "In Stock" : "Out of Stock"}</span>
              </div>
            </div>

            <div className="pt-4 border-t">
              <h3 className="font-medium mb-2">Composition</h3>
              <p className="text-sm text-muted-foreground">{medicine.composition}</p>
            </div>

            <AddToCartButton medicineId={medicine.id} />
          </div>
        </div>

        <div className="mt-12 space-y-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">Description</h2>
            <div className="prose max-w-none">
              <p>{medicine.description}</p>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Composition Details</h2>
            <div className="prose max-w-none">
              <p>{medicine.composition}</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

