import Link from "next/link"
import { Activity, Baby, Heart, Leaf, Pill, Stethoscope, type LucideIcon } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface CategoryCardProps {
  id: string
  name: string
  icon: string
  description: string
}

export function CategoryCard({ id, name, icon, description }: CategoryCardProps) {
  const getIcon = (): LucideIcon => {
    switch (icon) {
      case "pill":
        return Pill
      case "stethoscope":
        return Stethoscope
      case "heart":
        return Heart
      case "activity":
        return Activity
      case "baby":
        return Baby
      case "leaf":
        return Leaf
      default:
        return Pill
    }
  }

  const Icon = getIcon()

  return (
    <Link href={`/category/${id}`}>
      <Card className="h-full transition-all hover:shadow-md hover:border-primary/50">
        <CardContent className="flex flex-col items-center justify-center p-6 text-center">
          <Icon className="h-10 w-10 mb-3 text-primary" />
          <h3 className="font-medium">{name}</h3>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{description}</p>
        </CardContent>
      </Card>
    </Link>
  )
}

