import { db } from "@/lib/db"
import { MedicineCard } from "@/components/medicine/medicine-card"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface SearchResultsProps {
  searchParams: {
    q?: string
    category?: string
    minPrice?: string
    maxPrice?: string
    sort?: string
    page?: string
  }
}

export async function SearchResults({ searchParams }: SearchResultsProps) {
  const query = searchParams.q || ""
  const categories = searchParams.category?.split(",") || []
  const minPrice = searchParams.minPrice ? Number.parseFloat(searchParams.minPrice) : undefined
  const maxPrice = searchParams.maxPrice ? Number.parseFloat(searchParams.maxPrice) : undefined
  const sort = searchParams.sort || "relevance"
  const page = searchParams.page ? Number.parseInt(searchParams.page) : 1
  const pageSize = 12

  // Build the database query
  const where: any = {}

  // Search by name or content tags
  if (query) {
    where.OR = [
      { name: { contains: query, mode: "insensitive" } },
      { description: { contains: query, mode: "insensitive" } },
      { composition: { contains: query, mode: "insensitive" } },
      { contentTags: { has: query } },
    ]
  }

  // Filter by category
  if (categories.length > 0) {
    where.category = { in: categories }
  }

  // Filter by price
  if (minPrice !== undefined || maxPrice !== undefined) {
    where.OR = [
      ...(where.OR || []),
      {
        AND: [
          ...(minPrice !== undefined ? [{ price: { gte: minPrice } }] : []),
          ...(maxPrice !== undefined ? [{ price: { lte: maxPrice } }] : []),
        ],
      },
      {
        AND: [
          { discountPrice: { not: null } },
          ...(minPrice !== undefined ? [{ discountPrice: { gte: minPrice } }] : []),
          ...(maxPrice !== undefined ? [{ discountPrice: { lte: maxPrice } }] : []),
        ],
      },
    ]
  }

  // Determine sort order
  let orderBy: any = {}

  switch (sort) {
    case "price-asc":
      orderBy = { price: "asc" }
      break
    case "price-desc":
      orderBy = { price: "desc" }
      break
    case "newest":
      orderBy = { createdAt: "desc" }
      break
    default:
      // For relevance or if no sort is specified
      orderBy = { name: "asc" }
  }

  // Get total count for pagination
  const totalCount = await db.medicine.count({ where })
  const totalPages = Math.ceil(totalCount / pageSize)

  // Get medicines
  const medicines = await db.medicine.findMany({
    where,
    orderBy,
    skip: (page - 1) * pageSize,
    take: pageSize,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Showing {medicines.length} of {totalCount} results
        </p>
        <SortSelect currentSort={sort} />
      </div>

      {medicines.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {medicines.map((medicine) => (
            <MedicineCard
              key={medicine.id}
              id={medicine.id}
              name={medicine.name}
              description={medicine.description}
              price={medicine.price}
              discountPrice={medicine.discountPrice}
              image={medicine.image}
            />
          ))}
        </div>
      ) : (
        <div className="py-12 text-center">
          <h3 className="text-lg font-medium">No medicines found</h3>
          <p className="text-muted-foreground mt-1">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {totalPages > 1 && (
        <Pagination className="mt-8">
          <PaginationContent>
            {page > 1 && (
              <PaginationItem>
                <PaginationPrevious href={createPageUrl(searchParams, page - 1)} />
              </PaginationItem>
            )}

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNumber: number

              if (totalPages <= 5) {
                pageNumber = i + 1
              } else if (page <= 3) {
                pageNumber = i + 1
              } else if (page >= totalPages - 2) {
                pageNumber = totalPages - 4 + i
              } else {
                pageNumber = page - 2 + i
              }

              return (
                <PaginationItem key={pageNumber}>
                  <PaginationLink href={createPageUrl(searchParams, pageNumber)} isActive={page === pageNumber}>
                    {pageNumber}
                  </PaginationLink>
                </PaginationItem>
              )
            })}

            {page < totalPages && (
              <PaginationItem>
                <PaginationNext href={createPageUrl(searchParams, page + 1)} />
              </PaginationItem>
            )}
          </PaginationContent>
        </Pagination>
      )}
    </div>
  )
}

function createPageUrl(searchParams: SearchResultsProps["searchParams"], page: number) {
  const params = new URLSearchParams()

  if (searchParams.q) params.set("q", searchParams.q)
  if (searchParams.category) params.set("category", searchParams.category)
  if (searchParams.minPrice) params.set("minPrice", searchParams.minPrice)
  if (searchParams.maxPrice) params.set("maxPrice", searchParams.maxPrice)
  if (searchParams.sort) params.set("sort", searchParams.sort)

  params.set("page", page.toString())

  return `/search?${params.toString()}`
}

function SortSelect({ currentSort }: { currentSort: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm">Sort by:</span>
      <Select defaultValue={currentSort}>
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Sort by" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="relevance">Relevance</SelectItem>
          <SelectItem value="price-asc">Price: Low to High</SelectItem>
          <SelectItem value="price-desc">Price: High to Low</SelectItem>
          <SelectItem value="newest">Newest First</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

