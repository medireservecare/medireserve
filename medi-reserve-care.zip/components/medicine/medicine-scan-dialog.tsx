"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { extractTextFromImage } from "@/lib/medicine-scanner"
import { useToast } from "@/components/ui/use-toast"

interface MedicineScanDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onScanComplete: (result: string) => void
}

export function MedicineScanDialog({ open, onOpenChange, onScanComplete }: MedicineScanDialogProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("camera")
  const [isScanning, setIsScanning] = useState(false)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch (error) {
      console.error("Error accessing camera:", error)
      toast({
        variant: "destructive",
        title: "Camera Error",
        description: "Could not access your camera. Please check permissions.",
      })
    }
  }

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
      videoRef.current.srcObject = null
    }
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (context) {
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        const imageDataUrl = canvas.toDataURL("image/png")
        setCapturedImage(imageDataUrl)
        stopCamera()
      }
    }
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setCapturedImage(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const resetCapture = () => {
    setCapturedImage(null)
    if (activeTab === "camera") {
      startCamera()
    }
  }

  const processCapturedImage = async () => {
    if (!capturedImage) return

    setIsScanning(true)
    try {
      const extractedText = await extractTextFromImage(capturedImage)
      onScanComplete(extractedText)
      onOpenChange(false)
      toast({
        title: "Scan Complete",
        description: "Medicine information extracted successfully.",
      })
    } catch (error) {
      console.error("Error processing image:", error)
      toast({
        variant: "destructive",
        title: "Processing Error",
        description: "Could not extract medicine information. Please try again.",
      })
    } finally {
      setIsScanning(false)
    }
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setCapturedImage(null)

    if (value === "camera") {
      startCamera()
    } else {
      stopCamera()
    }
  }

  // Start/stop camera when dialog opens/closes
  const handleOpenChange = (open: boolean) => {
    if (open) {
      if (activeTab === "camera") {
        startCamera()
      }
    } else {
      stopCamera()
      setCapturedImage(null)
    }
    onOpenChange(open)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Scan Medicine</DialogTitle>
          <DialogDescription>
            Scan your medicine packaging or upload an image to find similar medicines.
          </DialogDescription>
        </DialogHeader>
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="camera">Camera</TabsTrigger>
            <TabsTrigger value="upload">Upload</TabsTrigger>
          </TabsList>
          <TabsContent value="camera" className="mt-4">
            {!capturedImage ? (
              <div className="relative aspect-video overflow-hidden rounded-md bg-muted">
                <video ref={videoRef} autoPlay playsInline className="h-full w-full object-cover" />
                <Button onClick={captureImage} className="absolute bottom-4 left-1/2 -translate-x-1/2">
                  Capture
                </Button>
              </div>
            ) : (
              <div className="relative aspect-video overflow-hidden rounded-md bg-muted">
                <img
                  src={capturedImage || "/placeholder.svg"}
                  alt="Captured medicine"
                  className="h-full w-full object-contain"
                />
                <Button variant="outline" size="icon" onClick={resetCapture} className="absolute top-2 right-2">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
          </TabsContent>
          <TabsContent value="upload" className="mt-4">
            {!capturedImage ? (
              <div className="flex flex-col items-center justify-center gap-4 rounded-md border border-dashed p-8">
                <Upload className="h-8 w-8 text-muted-foreground" />
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Drag and drop an image or click to browse</p>
                </div>
                <Button variant="secondary" onClick={() => fileInputRef.current?.click()}>
                  Select Image
                </Button>
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
              </div>
            ) : (
              <div className="relative aspect-video overflow-hidden rounded-md bg-muted">
                <img
                  src={capturedImage || "/placeholder.svg"}
                  alt="Uploaded medicine"
                  className="h-full w-full object-contain"
                />
                <Button variant="outline" size="icon" onClick={resetCapture} className="absolute top-2 right-2">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
        <canvas ref={canvasRef} className="hidden" />
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={processCapturedImage} disabled={!capturedImage || isScanning}>
            {isScanning ? "Processing..." : "Scan Medicine"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

