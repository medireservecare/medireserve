"use client"

import { useState } from "react"
import { Minus, Plus, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { addToCart } from "@/lib/cart-actions"

interface AddToCartButtonProps {
  medicineId: string
}

export function AddToCartButton({ medicineId }: AddToCartButtonProps) {
  const { toast } = useToast()
  const [quantity, setQuantity] = useState(1)
  const [isLoading, setIsLoading] = useState(false)

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const handleAddToCart = async () => {
    setIsLoading(true)
    try {
      await addToCart(medicineId, quantity)
      toast({
        title: "Added to cart",
        description: `${quantity} item(s) added to your cart.`,
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to add to cart",
        description: "Please try again later.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <Button variant="outline" size="icon" onClick={decreaseQuantity} disabled={quantity <= 1}>
          <Minus className="h-4 w-4" />
          <span className="sr-only">Decrease quantity</span>
        </Button>
        <span className="w-12 text-center">{quantity}</span>
        <Button variant="outline" size="icon" onClick={increaseQuantity}>
          <Plus className="h-4 w-4" />
          <span className="sr-only">Increase quantity</span>
        </Button>
      </div>
      <Button className="w-full" size="lg" onClick={handleAddToCart} disabled={isLoading}>
        {isLoading ? (
          "Adding to Cart..."
        ) : (
          <>
            <ShoppingCart className="mr-2 h-5 w-5" /> Add to Cart
          </>
        )}
      </Button>
    </div>
  )
}

