"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { addToCart } from "@/lib/cart-actions"

interface MedicineCardProps {
  id: string
  name: string
  description: string
  price: number
  discountPrice?: number | null
  image?: string | null
}

export function MedicineCard({ id, name, description, price, discountPrice, image }: MedicineCardProps) {
  const { toast } = useToast()
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)

  const handleAddToCart = async () => {
    setIsAddingToCart(true)
    try {
      await addToCart(id, 1)
      toast({
        title: "Added to cart",
        description: `${name} has been added to your cart.`,
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to add to cart",
        description: "Please try again later.",
      })
    } finally {
      setIsAddingToCart(false)
    }
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: `${name} has been ${isFavorite ? "removed from" : "added to"} your favorites.`,
    })
  }

  const discount = discountPrice ? Math.round(((price - discountPrice) / price) * 100) : 0

  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <div className="relative aspect-square">
        <Link href={`/medicines/${id}`}>
          <Image
            src={image || "/images/medicine-placeholder.jpg"}
            alt={name}
            fill
            className="object-cover transition-transform hover:scale-105"
          />
        </Link>
        {discount > 0 && (
          <div className="absolute top-2 right-2 bg-green-600 text-white text-xs font-medium px-2 py-1 rounded">
            {discount}% off
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 left-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white"
          onClick={toggleFavorite}
        >
          <Heart className={cn("h-4 w-4", isFavorite ? "fill-red-500 text-red-500" : "text-gray-600")} />
          <span className="sr-only">Add to favorites</span>
        </Button>
      </div>
      <CardContent className="p-4">
        <Link href={`/medicines/${id}`} className="hover:underline">
          <h3 className="font-medium line-clamp-1">{name}</h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{description}</p>
        <div className="mt-2 flex items-center gap-2">
          {discountPrice ? (
            <>
              <span className="font-semibold">₹{discountPrice.toFixed(2)}</span>
              <span className="text-sm text-muted-foreground line-through">₹{price.toFixed(2)}</span>
            </>
          ) : (
            <span className="font-semibold">₹{price.toFixed(2)}</span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button className="w-full" size="sm" onClick={handleAddToCart} disabled={isAddingToCart}>
          {isAddingToCart ? (
            "Adding..."
          ) : (
            <>
              <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

