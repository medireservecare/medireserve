"use client"

import { useState, useTransition } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function SearchFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isPending, startTransition] = useTransition()

  const [minPrice, setMinPrice] = useState(searchParams.get("minPrice") || "")
  const [maxPrice, setMaxPrice] = useState(searchParams.get("maxPrice") || "")

  const categories = [
    { id: "medicines", label: "Medicines" },
    { id: "healthcare", label: "Healthcare" },
    { id: "wellness", label: "Wellness" },
    { id: "fitness", label: "Fitness" },
    { id: "baby-care", label: "Baby Care" },
    { id: "ayurveda", label: "Ayurveda" },
  ]

  const selectedCategories = searchParams.get("category")?.split(",") || []

  const [selectedCategoryState, setSelectedCategoryState] = useState<string[]>(selectedCategories)

  const handleCategoryChange = (category: string, checked: boolean) => {
    const newSelectedCategories = checked
      ? [...selectedCategoryState, category]
      : selectedCategoryState.filter((c) => c !== category)

    setSelectedCategoryState(newSelectedCategories)

    startTransition(() => {
      const params = new URLSearchParams(searchParams)

      if (newSelectedCategories.length > 0) {
        params.set("category", newSelectedCategories.join(","))
      } else {
        params.delete("category")
      }

      router.push(`/search?${params.toString()}`)
    })
  }

  const handlePriceFilter = () => {
    startTransition(() => {
      const params = new URLSearchParams(searchParams)

      if (minPrice) {
        params.set("minPrice", minPrice)
      } else {
        params.delete("minPrice")
      }

      if (maxPrice) {
        params.set("maxPrice", maxPrice)
      } else {
        params.delete("maxPrice")
      }

      router.push(`/search?${params.toString()}`)
    })
  }

  const clearFilters = () => {
    setMinPrice("")
    setMaxPrice("")
    setSelectedCategoryState([])

    startTransition(() => {
      const params = new URLSearchParams(searchParams)
      params.delete("category")
      params.delete("minPrice")
      params.delete("maxPrice")

      // Keep the search query
      const query = params.get("q")

      router.push(query ? `/search?q=${query}` : "/search")
    })
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="font-medium">Filters</h3>
        <Button variant="outline" size="sm" onClick={clearFilters} className="w-full">
          Clear Filters
        </Button>
      </div>

      <Accordion type="multiple" defaultValue={["categories", "price"]}>
        <AccordionItem value="categories">
          <AccordionTrigger>Categories</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`category-${category.id}`}
                    checked={selectedCategoryState.includes(category.id)}
                    onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                  />
                  <Label htmlFor={`category-${category.id}`}>{category.label}</Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label htmlFor="min-price">Min Price</Label>
                  <Input
                    id="min-price"
                    type="number"
                    placeholder="₹0"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="max-price">Max Price</Label>
                  <Input
                    id="max-price"
                    type="number"
                    placeholder="₹1000"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                  />
                </div>
              </div>
              <Button size="sm" onClick={handlePriceFilter} disabled={isPending} className="w-full">
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

