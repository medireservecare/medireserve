"use client"

import type React from "react"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useSession, signOut } from "next-auth/react"
import { useState } from "react"
import { Search, Camera, ShoppingCart, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MedicineScanDialog } from "@/components/medicine/medicine-scan-dialog"

export function Header() {
  const { data: session } = useSession()
  const router = useRouter()
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScanDialogOpen, setIsScanDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  const handleScanResult = (result: string) => {
    setSearchQuery(result)
    router.push(`/search?q=${encodeURIComponent(result)}`)
  }

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center">
          <div className="md:hidden">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="mr-2">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col gap-4 mt-8">
                  <Link
                    href="/"
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium transition-colors hover:text-primary"
                  >
                    Home
                  </Link>
                  <Link
                    href="/medicines"
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium transition-colors hover:text-primary"
                  >
                    Medicines
                  </Link>
                  <Link
                    href="/healthcare"
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium transition-colors hover:text-primary"
                  >
                    Healthcare
                  </Link>
                  <Link
                    href="/wellness"
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium transition-colors hover:text-primary"
                  >
                    Wellness
                  </Link>
                  <Link
                    href="/ayurveda"
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-medium transition-colors hover:text-primary"
                  >
                    Ayurveda
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
          <Link href="/" className="flex items-center gap-2 mr-6">
            <span className="text-xl font-bold text-primary">MediReserveCare</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <Link
              href="/"
              className={`transition-colors hover:text-primary ${
                pathname === "/" ? "text-primary font-medium" : "text-foreground/60"
              }`}
            >
              Home
            </Link>
            <Link
              href="/medicines"
              className={`transition-colors hover:text-primary ${
                pathname === "/medicines" ? "text-primary font-medium" : "text-foreground/60"
              }`}
            >
              Medicines
            </Link>
            <Link
              href="/healthcare"
              className={`transition-colors hover:text-primary ${
                pathname === "/healthcare" ? "text-primary font-medium" : "text-foreground/60"
              }`}
            >
              Healthcare
            </Link>
            <Link
              href="/wellness"
              className={`transition-colors hover:text-primary ${
                pathname === "/wellness" ? "text-primary font-medium" : "text-foreground/60"
              }`}
            >
              Wellness
            </Link>
            <Link
              href="/ayurveda"
              className={`transition-colors hover:text-primary ${
                pathname === "/ayurveda" ? "text-primary font-medium" : "text-foreground/60"
              }`}
            >
              Ayurveda
            </Link>
          </nav>
          <div className="flex-1 mx-4">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search medicines..."
                className="w-full pl-8 pr-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-9 w-9"
                onClick={() => setIsScanDialogOpen(true)}
              >
                <Camera className="h-4 w-4" />
                <span className="sr-only">Scan medicine</span>
              </Button>
            </form>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="sr-only">Cart</span>
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                  0
                </span>
              </Button>
            </Link>
            {session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={session.user.image || ""} alt={session.user.name || ""} />
                      <AvatarFallback>
                        {session.user.name
                          ? session.user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                          : "U"}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/orders">Orders</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/prescriptions">Prescriptions</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut()}>Log out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="default" size="sm" asChild>
                <Link href="/login">Login</Link>
              </Button>
            )}
          </div>
        </div>
      </header>
      <MedicineScanDialog
        open={isScanDialogOpen}
        onOpenChange={setIsScanDialogOpen}
        onScanComplete={handleScanResult}
      />
    </>
  )
}

