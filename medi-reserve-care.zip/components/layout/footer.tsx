import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4 lg:grid-cols-5">
          <div className="col-span-2 lg:col-span-2">
            <Link href="/" className="text-xl font-bold text-primary">
              MediReserveCare
            </Link>
            <p className="mt-2 text-sm text-muted-foreground">
              Your trusted partner for all your healthcare needs. We provide authentic medicines and healthcare products
              at your doorstep.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-medium">Quick Links</h3>
            <ul className="mt-2 space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-foreground">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/medicines" className="text-muted-foreground hover:text-foreground">
                  Medicines
                </Link>
              </li>
              <li>
                <Link href="/healthcare" className="text-muted-foreground hover:text-foreground">
                  Healthcare
                </Link>
              </li>
              <li>
                <Link href="/wellness" className="text-muted-foreground hover:text-foreground">
                  Wellness
                </Link>
              </li>
              <li>
                <Link href="/ayurveda" className="text-muted-foreground hover:text-foreground">
                  Ayurveda
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-medium">Support</h3>
            <ul className="mt-2 space-y-2 text-sm">
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-foreground">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="text-muted-foreground hover:text-foreground">
                  Shipping Policy
                </Link>
              </li>
              <li>
                <Link href="/returns" className="text-muted-foreground hover:text-foreground">
                  Return Policy
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-medium">Contact</h3>
            <ul className="mt-2 space-y-2 text-sm">
              <li className="text-muted-foreground">1234 Health Avenue, Medical District, City - 123456</li>
              <li className="text-muted-foreground">Email: support@medireservecare.com</li>
              <li className="text-muted-foreground">Phone: +1 (123) 456-7890</li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} MediReserveCare. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

