"use server"

import { cookies } from "next/headers"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { db } from "@/lib/db"

// Helper to get or create a cart ID
async function getCartId() {
  const session = await getServerSession(authOptions)

  // If user is logged in, use their ID as cart ID
  if (session?.user?.id) {
    return `user_${session.user.id}`
  }

  // Otherwise, use a cookie-based cart ID
  const cookieStore = cookies()
  let cartId = cookieStore.get("cart_id")?.value

  if (!cartId) {
    cartId = `guest_${Math.random().toString(36).substring(2, 15)}`
    cookieStore.set("cart_id", cartId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 30, // 30 days
      path: "/",
    })
  }

  return cartId
}

// Add item to cart
export async function addToCart(medicineId: string, quantity: number) {
  const cartId = await getCartId()

  // Check if medicine exists
  const medicine = await db.medicine.findUnique({
    where: { id: medicineId },
  })

  if (!medicine) {
    throw new Error("Medicine not found")
  }

  // Get current cart items
  const cartItems = JSON.parse(cookies().get("cart_items")?.value || "[]")

  // Check if item already exists in cart
  const existingItemIndex = cartItems.findIndex((item: any) => item.medicineId === medicineId)

  if (existingItemIndex > -1) {
    // Update quantity if item exists
    cartItems[existingItemIndex].quantity += quantity
  } else {
    // Add new item if it doesn't exist
    cartItems.push({
      medicineId,
      quantity,
      price: medicine.discountPrice || medicine.price,
      name: medicine.name,
      image: medicine.image,
    })
  }

  // Save updated cart
  cookies().set("cart_items", JSON.stringify(cartItems), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 30, // 30 days
    path: "/",
  })

  return { success: true }
}

// Remove item from cart
export async function removeFromCart(medicineId: string) {
  // Get current cart items
  const cartItems = JSON.parse(cookies().get("cart_items")?.value || "[]")

  // Filter out the item to remove
  const updatedCartItems = cartItems.filter((item: any) => item.medicineId !== medicineId)

  // Save updated cart
  cookies().set("cart_items", JSON.stringify(updatedCartItems), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 30, // 30 days
    path: "/",
  })

  return { success: true }
}

// Update item quantity in cart
export async function updateCartItemQuantity(medicineId: string, quantity: number) {
  if (quantity < 1) {
    return removeFromCart(medicineId)
  }

  // Get current cart items
  const cartItems = JSON.parse(cookies().get("cart_items")?.value || "[]")

  // Find the item to update
  const itemIndex = cartItems.findIndex((item: any) => item.medicineId === medicineId)

  if (itemIndex > -1) {
    // Update quantity
    cartItems[itemIndex].quantity = quantity

    // Save updated cart
    cookies().set("cart_items", JSON.stringify(cartItems), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 30, // 30 days
      path: "/",
    })

    return { success: true }
  }

  return { success: false, message: "Item not found in cart" }
}

// Get cart items
export async function getCartItems() {
  return JSON.parse(cookies().get("cart_items")?.value || "[]")
}

