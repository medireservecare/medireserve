import { createWorker } from "tesseract.js"

export async function extractTextFromImage(imageDataUrl: string): Promise<string> {
  try {
    // Initialize Tesseract.js worker
    const worker = await createWorker("eng")

    // Recognize text from image
    const {
      data: { text },
    } = await worker.recognize(imageDataUrl)

    // Terminate worker
    await worker.terminate()

    // Process the extracted text to identify medicine content
    const processedText = processMedicineText(text)

    return processedText
  } catch (error) {
    console.error("Error extracting text from image:", error)
    throw new Error("Failed to extract text from image")
  }
}

function processMedicineText(text: string): string {
  // Remove extra whitespace and normalize text
  const processedText = text.replace(/\s+/g, " ").trim()

  // Extract potential medicine names and ingredients
  // This is a simplified version -  ').trim()

  // Extract potential medicine names and ingredients
  // This is a simplified version - in a real app, you would use more sophisticated NLP
  const medicineNameRegex = /\b[A-Z][a-z]+ (?:[A-Z][a-z]+)?\b/g
  const ingredientRegex =
    /\b(?:paracetamol|ibuprofen|aspirin|amoxicillin|omeprazole|atorvastatin|metformin|salbutamol|fluoxetine|simvastatin)\b/gi

  const medicineNames = processedText.match(medicineNameRegex) || []
  const ingredients = processedText.match(ingredientRegex) || []

  // Combine the results, prioritizing ingredients
  const result = [...new Set([...ingredients, ...medicineNames])].join(" ")

  return result || processedText
}

